# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu
#
#      Modified for FTV Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import xbmc
import xbmcaddon
import time
time = 2000 #in miliseconds

import gui

import os
import sys
import xbmcgui
import urllib2
import httplib
import urllib
import re, json

def checkingeverything(TARGETFOLDER, MAIN_URL,__addonname__,newicon,registermessage1,registermessage2,seeurl):
  try:
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Getting latest data', time, newicon))
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,'Reading data', time, newicon))

    playerusername = xbmcaddon.Addon('plugin.video.VadersIPCC').getSetting("username")
    playerpassword = xbmcaddon.Addon('plugin.video.VadersIPCC').getSetting("password")

    if not os.path.exists(TARGETFOLDER): os.makedirs(TARGETFOLDER)
    MAIN_URL = 'http://pythonwithphp.com/IPCableCloud/GuideVadersV2/'
    import requests
    import shutil
    r = requests.get(MAIN_URL+'addons.ini', stream=True, headers={'User-agent': 'Mozilla/5.0'})
    if r.status_code == 200:
        with open(TARGETFOLDER+"addons.ini", 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)

    r = requests.get(MAIN_URL+'categories.ini', stream=True, headers={'User-agent': 'Mozilla/5.0'})
    if r.status_code == 200:
        with open(TARGETFOLDER+"categories.ini", 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)
    TARGETFOLDERFile = TARGETFOLDER+'addons.ini'

    # Read in the file
    filedata = None
    with open(TARGETFOLDERFile, 'r') as file :
      filedata = file.read()

    # Replace the target string
    filedata = filedata.replace('vaderuser', playerusername)

    # Write the file out again
    with open(TARGETFOLDERFile, 'w') as file:
      file.write(filedata)

    # Read in the file
    filedata = None
    with open(TARGETFOLDERFile, 'r') as file :
      filedata = file.read()

    # Replace the target string
    filedata = filedata.replace('vaderpass', playerpassword)

    # Write the file out again
    with open(TARGETFOLDERFile, 'w') as file:
      file.write(filedata)

    line1 = 'Cloud Connection Opened!'

    completed = 'True'
    return completed
  except Exception as e:
    xbmcgui.Dialog().ok(__addonname__, str(e))
    completed = 'False'
    xbmcgui.Dialog().ok(__addonname__, 'Do a Guide Reset and then open Guide')
    sys.exit(0)

    return completed
